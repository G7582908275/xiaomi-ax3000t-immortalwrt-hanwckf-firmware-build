#!/bin/sh

path_src=$1
path_des=$2
mv $path_src $path_des
