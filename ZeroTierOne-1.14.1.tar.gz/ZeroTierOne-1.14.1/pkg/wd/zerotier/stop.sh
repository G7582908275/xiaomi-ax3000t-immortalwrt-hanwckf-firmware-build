#! /bin/sh

killall zerotier-one
