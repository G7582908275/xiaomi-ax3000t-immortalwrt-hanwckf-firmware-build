#! /bin/sh

/usr/bin/zerotier-one -d