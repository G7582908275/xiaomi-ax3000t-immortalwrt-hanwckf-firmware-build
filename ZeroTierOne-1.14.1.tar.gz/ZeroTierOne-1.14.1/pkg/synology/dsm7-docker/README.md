## Docker image for Synology's DSM7

Documentation: [docs.zerotier.com/devices/synology](https://docs.zerotier.com/devices/synology)

### Build & Push changes to DockerHub
```shell
./build.sh build
```
